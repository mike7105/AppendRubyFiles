# -*- coding: utf-8 -*-
"""AppendRubyFiles GUI"""
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as msgbox
import tkinter.filedialog as tkFD
import os
import sys
import traceback
import time
import threading
import queue
import glob
import shutil

class Application(ttk.Frame):
    """класс для отрисовки AppendRubyFiles"""
    def __init__(self, master=None, version=""):
        super().__init__(master)
        self.master = master
        self.version = version
        self.grid_params = {"padx": 5, "pady": 5}
        self.grid(row=0, column=0, columnspan=2, sticky="wnse", **self.grid_params)
        
        self.frame1 = ttk.Frame()
        self.frame1.grid(row=0, column=0, columnspan=2, sticky="wnse", **self.grid_params)

        # ButtonRun
        self.btn_run = ttk.Button(text="Пуск", command=self.run_append)
        self.btn_run.grid(row=1, column=0, sticky="es", **self.grid_params)

        # ButtonExit
        self.btn_exit = ttk.Button(text="Выход", command=self.master.destroy)
        self.btn_exit.grid(row=1, column=1, sticky="es", **self.grid_params)

        # ProgressBar
        self.var_pb = tk.IntVar()
        self.pgb = ttk.Progressbar(maximum=100, variable=self.var_pb)
        self.var_pb.set(0)
        self.pgb.grid(row=2, column=0, columnspan=2, sticky="we")

        # LabelStatus
        self.var_status = tk.StringVar()
        self.var_status.set("")
        self.lbl_status = ttk.Label(textvariable=self.var_status, relief=tk.RIDGE)
        self.lbl_status.grid(row=3, column=0, columnspan=2, sticky="wes")

        # Sizegrip
        self.sgp = ttk.Sizegrip()
        self.sgp.grid(row=3, column=1, sticky="es")

        self.master.grid_rowconfigure(0, weight=1)
        self.master.grid_columnconfigure(0, weight=10)
        self.master.grid_columnconfigure(1, weight=1)

        self.master.title("AppendRubyFiles")
        self.master.minsize(width=400, height=300)

        self.create_menu()
        self.create_widgets()

        # #####STYLE#######
        self.style = ttk.Style()

    def create_menu(self):
        """Создание меню"""
        # Создаем само главное меню и назначаем его окну приложения
        window = self.master
        self.mainmenu = tk.Menu(window, tearoff=False)
        window["menu"] = self.mainmenu

        # Создаем подменю Файл
        self.filemenu = tk.Menu(self.mainmenu, tearoff=False)

        self.filemenu.add_separator()

        self.filemenu.add_command(
            label="Выход", accelerator="Ctrl+Q", command=self.master.destroy)
        self.bind_all(
            "<Control-KeyPress-q>", lambda evt: self.btn_exit.invoke())

        self.mainmenu.add_cascade(label="Файл", menu=self.filemenu)

        # Добавляем меню Настройки в главное меню
        self.thememenu = tk.Menu(self.mainmenu, tearoff=False)

        self.them = tk.StringVar()
        self.them.set("vista")
        self.tharr = [
            "default", "winnative", "clam", "alt", "classic", "vista", "xpnative"]

        for style in self.tharr:
            self.thememenu.add_radiobutton(
                label=style, variable=self.them, value=style,
                command=self.change_theme)
        self.mainmenu.add_cascade(label="Темы", menu=self.thememenu)

        # Создаем подменю Справка
        self.helpmenu = tk.Menu(self.mainmenu, tearoff=False)
        self.helpmenu.add_command(label="О программе...", command=self.show_info)
        self.mainmenu.add_cascade(label="Справка", menu=self.helpmenu)

        # Контекстное меню
        self.contextmenu = tk.Menu(self, tearoff=False)
        self.contextmenu.add_command(label="Скопировать", command=self.copy)

    def create_widgets(self):
        """создает компненты GUI"""
        # список элементов, которые нужно блокировать
        self.elems = []

        

        # LabelPrev
        self.lbl_prev = ttk.Label(self.frame1, text="Choose Casedata from previous waves:")
        self.lbl_prev.grid(
            row=0, column=0, columnspan=2, sticky="we", **self.grid_params)

        # EntryPrev
        self.var_prev = tk.StringVar()
        self.var_prev.set("")
        self.ent_prev = ttk.Entry(self.frame1, textvariable=self.var_prev)
        self.ent_prev.state(["disabled"])
        self.ent_prev.bind(
            "<Button-3>", lambda evt, obj=self.var_prev: self.show_menu(evt, obj))
        self.ent_prev.grid(row=1, column=0, sticky="we", **self.grid_params)

        # ButtonPrev
        self.btn_prev = ttk.Button(self.frame1, text="Choose...", command = lambda: self.open_dir(self.var_prev))
        self.btn_prev.grid(row=1, column=1, sticky="e", **self.grid_params)
        self.elems.append(self.btn_prev)

        # LabelCurr
        self.lbl_curr = ttk.Label(self.frame1, text="Choose Casedata from last wave:")
        self.lbl_curr.grid(
            row=2, column=0, columnspan=2, sticky="we", **self.grid_params)

        # EntryCurr
        self.var_curr = tk.StringVar()
        self.var_curr.set("")
        self.ent_curr = ttk.Entry(self.frame1, textvariable=self.var_curr)
        self.ent_curr.state(["disabled"])
        self.ent_curr.bind(
            "<Button-3>", lambda evt, obj=self.var_curr: self.show_menu(evt, obj))
        self.ent_curr.grid(row=3, column=0, sticky="we", **self.grid_params)

        # ButtonCurr
        self.btn_curr = ttk.Button(self.frame1, text="Choose...", command = lambda: self.open_dir(self.var_curr))
        self.btn_curr.grid(row=3, column=1, sticky="e", **self.grid_params)
        self.elems.append(self.btn_curr)

        # LabelRes
        self.lbl_res = ttk.Label(self.frame1, text="Choose Casedata for appended waves:")
        self.lbl_res.grid(
            row=4, column=0, columnspan=2, sticky="we", **self.grid_params)

        # EntryRes
        self.var_res = tk.StringVar()
        self.var_res.set("")
        self.ent_res = ttk.Entry(self.frame1, textvariable=self.var_res)
        self.ent_res.state(["disabled"])
        self.ent_res.bind(
            "<Button-3>", lambda evt, obj=self.var_curr: self.show_menu(evt, obj))
        self.ent_res.grid(row=5, column=0, sticky="we", **self.grid_params)

        # ButtonRes
        self.btn_res = ttk.Button(self.frame1, text="Choose...", command = lambda: self.open_dir(self.var_res))
        self.btn_res.grid(row=5, column=1, sticky="e", **self.grid_params)
        self.elems.append(self.btn_res)

        
        self.frame1.grid_columnconfigure(0, weight=10)
        self.frame1.grid_columnconfigure(1, weight=1)

    def run_append(self):
        """запускает присоединение файлов"""
        self.change_state(False)
        self.var_status.set("")
        if self.validate():
            self.t1 = time.time()
            self.num_prev = 0
            self.num_same = 0
            self.num_new = 0

            # копирую все файлы met
            self.var_status.set("copy met files")
            for met_file in glob.glob(self.var_curr.get() + "\\*.met"):
                shutil.copy(met_file, self.var_res.get())

            self.cd_files = glob.glob(self.var_curr.get() + "\\*.cd")
            self.pgb["maximum"] = len(self.cd_files)
            
            if os.path.exists(os.path.join(self.var_prev.get(), "id.cd")):
                self.num_prev = self.count_lines(os.path.join(self.var_prev.get(), "id.cd"))

            # прохожусь по всем cd файлам self.var_curr
            self.var_status.set("copy cd files")
            for cd_file_c in self.cd_files:
                cd_file_p = os.path.join(self.var_prev.get(), os.path.split(cd_file_c)[1])
   
                # если в self.var_prev есть такой же файл, то его копирую и 
                # дописываю содержимым файла из self.var_curr
                if os.path.exists(cd_file_p):
                    self.num_same += 1
                    if self.num_prev == 0:
                        self.num_prev = self.count_lines(cd_file_p)

                    cd_file_r = shutil.copy(cd_file_p, self.var_res.get())

                    with open(cd_file_c, 'rb') as fsrc:
                        with open(cd_file_r, 'ab') as fdst:
                            shutil.copyfileobj(fsrc, fdst)
                            self.var_status.set(os.path.basename(cd_file_r))
                            # self.pgb.step()
                            self.after(0, self.pgb.step())
                            self.pgb.update() 

                # если файла нет, то нужно создать пустой с определенным кол-вом строк
                else:
                    self.num_new += 1
                    cd_file_r = os.path.join(self.var_res.get(), os.path.split(cd_file_c)[1])

                    with open(cd_file_r, 'w') as f:
                        f.write('\n' * self.num_prev)

                    with open(cd_file_c, 'rb') as fsrc:
                        with open(cd_file_r, 'ab') as fdst:
                            shutil.copyfileobj(fsrc, fdst)
                            self.var_status.set(os.path.basename(cd_file_r))
                            # self.pgb.step()
                            self.after(0, self.pgb.step())
                            self.pgb.update() 

            self.t2 = time.time()
            self.tr = self.t2 - self.t1
            self.var_status.set("same files {0}; new files {1}; duration {2:.3f}".format(
                self.num_same, self.num_new, self.tr))
        self.change_state(True)

    def count_lines(self, filename, chunk_size=1<<13):
        """считает кол-во строк в файле"""
        with open(filename) as file:
            chunk = '\n'
            nlines = 0
            for chunk in iter(lambda: file.read(chunk_size), ''):
                nlines += chunk.count('\n')
        return nlines + (not chunk.endswith('\n'))

    def open_dir(self, obj):
        """Выбор директории"""
        self.var_status.set("")
        filename = tkFD.askdirectory()
        if filename:
            obj.set(filename)
        else:
            msgbox.showerror("Choose CaseData folder", "Folder wasn't chosen!")

    def show_info(self):
        """Показ информации"""
        msgbox.showinfo("О программе...", """{0}
        © Михаил Чесноков, 2019 г.
        mailto: Mihail.Chesnokov@ipsos.com""".format(self.version), parent=self)

    def show_menu(self, evt, obj):
        """Показывает контекстное меню"""
        self.to_copy = obj.get()
        self.contextmenu.post(evt.x_root, evt.y_root)

    def copy(self):
        """Копирует содержимое путей"""
        # print(self.to_copy)
        self.clipboard_clear()
        self.clipboard_append(self.to_copy)

    def change_theme(self):
        """меняет внешний вид при выборе встроенных тем"""
        self.style.theme_use(self.them.get())

    def validate(self) -> bool:
        """проверка введенных значений"""
        res = ""
        if not self.var_prev.get():
            res = "Choose previous waves CaseData!\n"
        if not self.var_curr.get():
            res = res + "Choose last wave CaseData!\n"
        if not self.var_res.get():
            res = res + "Choose result CaseData!"
        if res:
            msgbox.showerror("Validation fail", res)
            return False
        return True

    def change_state(self, is_visible):
        """меняет активность элементов"""
        for elem in self.elems:
            if is_visible:
                if hasattr(elem, 'state'):
                    elem.state(["!disabled"])
                else:
                    elem.config(state="normal")
            else:
                if hasattr(elem, 'state'):
                    elem.state(["disabled"])
                else:
                    elem.config(state="disabled")

if __name__ == "__main__":
    pass

